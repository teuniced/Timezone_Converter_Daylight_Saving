
from collections import Counter
import time
from word2number import w2n
from datetime import datetime
import pytz
from pprint import pprint






print(" Time Zone Converter".center(75,"~"))
#“Eastern Standard Time” 
tzst = pytz.timezone("EST")# pyzt module retrieves timezone info. 
#pytz.all_timezones attribute returns the list of all supported time zones as a list object
datetime.now(tzst) 
w = datetime.now(tzst) #formats datetime into readable string in variable "w"
wintertime = w.strftime("%a" "," " " "%b" " " "%d" "," " " "%Y" " ""%H"":""%M""%p"" " "%Z") #specifies the format of the returned string
print(f"The local standard time now is {wintertime}")

#taking into account DST “Eastern Daylight Time.
tzdt = pytz.timezone("America/New_York")
datetime.now(tzdt) 
s = datetime.now(tzdt) 
springtime = s.strftime("%a" "," " " "%b" " " "%d" "," " " "%Y" " ""%H"":""%M" "%p"" " "%Z")
print(f"The local time now for Daylight saving is {springtime}")

"""
    REFERENCES
    %a	Weekday, short version
    %b	Month name, short version
    %d  Day of month
    %Y	Year, full version
    %H	Hour
    %M	Minute
    %p	AM/PM
    %Z	Timezone
    https://www.w3schools.com/python/python_datetime.asp
"""